# Study 2 analysis code

This repository contains R code for the Study 2 analyses accompanying the manuscript.

## Repository structure

- `R/01_data_preparation.R` — imports the local REDCap/SPSS export, restricts the data to baseline, constructs CAT-Q subscales, clinical variables, formal-support variables, and diagnosis indicators.
- `R/02_primary_analyses.R` — descriptive and primary analyses of CAT-Q, formal support, clinical variables, and psychiatric diagnoses.
- `R/03_masking_support_sensitivity.R` — analyses of CAT-Q masking by number of formal support types, WHODAS-adjusted partial correlations, and leave-one-out sensitivity analyses.

## Data availability and privacy

Raw participant-level data are **not included** in this repository. The analysis scripts are intended to be run against an authorized local copy of the study data. Do not commit REDCap/SPSS exports, participant identifiers, or other potentially identifying study files.

## Requirements

R packages used across the scripts include:

- `haven`
- `dplyr`
- `ppcor`

Install missing packages from CRAN before running the analysis.

## Running the analysis

Set the path to the local SPSS export using the `STUDY2_DATA_FILE` environment variable. For example, within R:

```r
Sys.setenv(STUDY2_DATA_FILE = "path/to/local/study_data.sav")
source("R/01_data_preparation.R")
source("R/02_primary_analyses.R")
source("R/03_masking_support_sensitivity.R")
```

The raw data path is intentionally not hard-coded so that local usernames and file-system information are not exposed in the public repository.

## Reproducibility

The analysis scripts use complete-case subsets appropriate to each analysis. CAT-Q subscale means are calculated using the completion criterion implemented in the study analysis code. Spearman correlations and non-parametric group comparisons are used where specified in the manuscript analysis workflow.

The sensitivity script reports `sessionInfo()` to document the R environment used when the analyses are run.

## Citation

If this repository accompanies a publication, add the final manuscript citation and DOI here after publication.

## License

Add the license approved by the research team/institution before making the repository public. If no license is provided, others do not automatically receive permission to reuse the code.
