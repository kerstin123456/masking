# Study 2: data preparation
#
# This script prepares the baseline analytic dataset used by the Study 2
# analyses. Raw study data are NOT included in this repository.
#
# Expected input: a REDCap/SPSS export supplied locally by the analyst.

library(haven)
library(dplyr)

# ---- User setting ---------------------------------------------------------
# Set this to the local path of the de-identified/raw data export.
# Do not commit the source data to GitHub.
data_file <- Sys.getenv("STUDY2_DATA_FILE")
if (data_file == "") {
  stop("Set environment variable STUDY2_DATA_FILE to the local .sav file.")
}

# ---- Load baseline data ---------------------------------------------------
dat_raw <- read_sav(data_file)

dat <- dat_raw %>%
  filter(as.character(redcap_event_name) == "baseline_arm_1")

stopifnot(nrow(dat) == dplyr::n_distinct(dat$record_id))

# ---- CAT-Q subscales ------------------------------------------------------
catq_items <- paste0("t0_catq_", 1:25)
dat[catq_items] <- lapply(dat[catq_items], as.numeric)

reverse_items <- c(3, 12, 19, 22, 24)
for (i in reverse_items) {
  oldvar <- paste0("t0_catq_", i)
  newvar <- paste0(oldvar, "_r")
  dat[[newvar]] <- ifelse(is.na(dat[[oldvar]]), NA, 8 - dat[[oldvar]])
}

comp_items <- c(
  "t0_catq_1", "t0_catq_4", "t0_catq_5", "t0_catq_8", "t0_catq_11",
  "t0_catq_14", "t0_catq_17", "t0_catq_20", "t0_catq_23"
)
mask_items <- c(
  "t0_catq_2", "t0_catq_6", "t0_catq_9", "t0_catq_12_r",
  "t0_catq_15", "t0_catq_18", "t0_catq_21", "t0_catq_24_r"
)
assim_items <- c(
  "t0_catq_3_r", "t0_catq_7", "t0_catq_10", "t0_catq_13",
  "t0_catq_16", "t0_catq_19_r", "t0_catq_22_r", "t0_catq_25"
)

dat$n_comp  <- rowSums(!is.na(dat[comp_items]))
dat$n_mask  <- rowSums(!is.na(dat[mask_items]))
dat$n_assim <- rowSums(!is.na(dat[assim_items]))

# >=80% completion criterion used in the study analysis.
dat$catq_compensation <- ifelse(
  dat$n_comp >= 8, rowMeans(dat[comp_items], na.rm = TRUE), NA
)
dat$catq_masking <- ifelse(
  dat$n_mask >= 7, rowMeans(dat[mask_items], na.rm = TRUE), NA
)
dat$catq_assimilation <- ifelse(
  dat$n_assim >= 7, rowMeans(dat[assim_items], na.rm = TRUE), NA
)

# ---- Clinical variables --------------------------------------------------
dat <- dat %>%
  mutate(
    phq9 = as.numeric(gsub(",", ".", t0_phq9)),
    gad7 = as.numeric(gsub(",", ".", t0_gad_7)),
    whodas = as.numeric(gsub(",", ".", t0_whodas)),
    swls = as.numeric(gsub(",", ".", t0_swls))
  )

# ---- Formal support ------------------------------------------------------
support_items <- paste0("t0_dem_help___", 1:7)
dat[support_items] <- lapply(dat[support_items], as.numeric)

dat$n_support_types <- ifelse(
  rowSums(!is.na(dat[support_items])) > 0,
  rowSums(dat[support_items], na.rm = TRUE),
  NA
)

dat$any_support <- ifelse(
  is.na(dat$n_support_types), NA, as.integer(dat$n_support_types > 0)
)

# ---- Psychiatric diagnosis indicators -----------------------------------
diagnosis_string <- paste(
  dat$t0_a_dia_1, dat$t0_a_diag_2, dat$t0_a_diag_3, dat$t0_a_diag_4,
  sep = "|"
)

dat$dx_adhd <- as.integer(grepl("F90", diagnosis_string))
dat$dx_depression <- as.integer(grepl("F32|F33", diagnosis_string))
dat$dx_anxiety <- as.integer(grepl("F40|F41", diagnosis_string))

# Keep `dat` in memory for scripts sourced interactively.
message("Prepared baseline dataset: ", nrow(dat), " participants.")
