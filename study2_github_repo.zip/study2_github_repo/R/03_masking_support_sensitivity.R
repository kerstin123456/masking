# ==============================================================================
# Masking and Number of Formal Support Types
# ==============================================================================
# Purpose:
#   Examine the association between CAT-Q Masking scores and the number of
#   formal support types received (0-3), including adjustment for WHODAS and
#   leave-one-out sensitivity analyses.
#
# Required input object:
#   dat
#
# Required variables in `dat`:
#   catq_masking     CAT-Q Masking subscale score
#   n_support_types  Number of formal support types
#   whodas           WHODAS score
#
# Packages:
#   dplyr, ppcor
# ============================================================================== 

# ---- Packages -----------------------------------------------------------------

library(dplyr)
library(ppcor)

# ---- Analysis sample ----------------------------------------------------------

mask_support_count <- dat %>%
  filter(
    !is.na(catq_masking),
    !is.na(n_support_types)
  )

cat("Analysis N:", nrow(mask_support_count), "\n")
cat("\nDistribution of number of support types:\n")
print(table(mask_support_count$n_support_types))

# ---- 1. Descriptive statistics ------------------------------------------------

masking_descriptives <- mask_support_count %>%
  group_by(n_support_types) %>%
  summarise(
    n = n(),
    mean = mean(catq_masking),
    sd = sd(catq_masking),
    median = median(catq_masking),
    iqr = IQR(catq_masking),
    min = min(catq_masking),
    max = max(catq_masking),
    .groups = "drop"
  )

cat("\nMasking descriptives by number of support types:\n")
print(masking_descriptives)

# ---- 2. Spearman correlation --------------------------------------------------
# Treat number of support types as an ordered count (0, 1, 2, 3).

spearman_support <- cor.test(
  mask_support_count$catq_masking,
  mask_support_count$n_support_types,
  method = "spearman",
  exact = FALSE
)

cat("\nSpearman correlation: masking x support count\n")
print(spearman_support)

# ---- 3. Kruskal-Wallis test ---------------------------------------------------
# Treat 0, 1, 2, and 3 support types as separate groups.

kruskal_support <- kruskal.test(
  catq_masking ~ factor(n_support_types),
  data = mask_support_count
)

cat("\nKruskal-Wallis test across support-count groups:\n")
print(kruskal_support)

# ---- 4. Partial Spearman correlations adjusted for WHODAS --------------------

count_adjusted <- dat %>%
  filter(
    !is.na(catq_masking),
    !is.na(n_support_types),
    !is.na(whodas)
  )

cat("\nWHODAS-adjusted analysis N:", nrow(count_adjusted), "\n")

partial_masking_support <- ppcor::pcor.test(
  count_adjusted$catq_masking,
  count_adjusted$n_support_types,
  count_adjusted$whodas,
  method = "spearman"
)

partial_whodas_support <- ppcor::pcor.test(
  count_adjusted$whodas,
  count_adjusted$n_support_types,
  count_adjusted$catq_masking,
  method = "spearman"
)

cat("\nPartial Spearman: masking x support count, adjusted for WHODAS\n")
print(partial_masking_support)

cat("\nPartial Spearman: WHODAS x support count, adjusted for masking\n")
print(partial_whodas_support)

# ---- 5. Leave-one-out sensitivity analysis -----------------------------------
# Each row is omitted once. No participant IDs are included in the output.

loo_results <- data.frame(
  omitted_row = seq_len(nrow(mask_support_count)),
  support_types = mask_support_count$n_support_types,
  masking = mask_support_count$catq_masking,
  rho = NA_real_,
  p = NA_real_
)

for (i in seq_len(nrow(mask_support_count))) {
  tmp <- mask_support_count[-i, , drop = FALSE]

  test <- cor.test(
    tmp$catq_masking,
    tmp$n_support_types,
    method = "spearman",
    exact = FALSE
  )

  loo_results$rho[i] <- unname(test$estimate)
  loo_results$p[i] <- test$p.value
}

loo_results <- loo_results %>%
  arrange(p) %>%
  as_tibble()

cat("\nLeave-one-out Spearman rho range:\n")
print(range(loo_results$rho, na.rm = TRUE))

cat("\nLeave-one-out p-value range:\n")
print(range(loo_results$p, na.rm = TRUE))

cat("\nLeave-one-out results for observations with >=2 support types:\n")
print(
  loo_results %>%
    filter(support_types >= 2) %>%
    select(support_types, masking, rho, p)
)

# ---- 6. Sensitivity analysis restricted to 0-1 support types -----------------

support_01 <- mask_support_count %>%
  filter(n_support_types <= 1)

spearman_support_01 <- cor.test(
  support_01$catq_masking,
  support_01$n_support_types,
  method = "spearman",
  exact = FALSE
)

support_01_descriptives <- support_01 %>%
  group_by(n_support_types) %>%
  summarise(
    n = n(),
    mean = mean(catq_masking),
    sd = sd(catq_masking),
    median = median(catq_masking),
    iqr = IQR(catq_masking),
    .groups = "drop"
  )

cat("\nSpearman correlation restricted to 0-1 support types:\n")
print(spearman_support_01)

cat("\nDescriptives restricted to 0-1 support types:\n")
print(support_01_descriptives)

# ---- 7. Leave-one-out partial Spearman correlation ---------------------------

loo_partial <- data.frame(
  omitted_row = seq_len(nrow(count_adjusted)),
  support_types = count_adjusted$n_support_types,
  masking = count_adjusted$catq_masking,
  partial_rho = NA_real_,
  p = NA_real_
)

for (i in seq_len(nrow(count_adjusted))) {
  tmp <- count_adjusted[-i, , drop = FALSE]

  test <- ppcor::pcor.test(
    tmp$catq_masking,
    tmp$n_support_types,
    tmp$whodas,
    method = "spearman"
  )

  loo_partial$partial_rho[i] <- unname(test$estimate)
  loo_partial$p[i] <- test$p.value
}

loo_partial <- loo_partial %>%
  arrange(p) %>%
  as_tibble()

cat("\nLeave-one-out partial rho range:\n")
print(range(loo_partial$partial_rho, na.rm = TRUE))

cat("\nLeave-one-out partial-correlation p-value range:\n")
print(range(loo_partial$p, na.rm = TRUE))

cat("\nPartial-correlation leave-one-out results for observations with >=2 support types:\n")
print(
  loo_partial %>%
    filter(support_types >= 2) %>%
    select(support_types, masking, partial_rho, p)
)

# ---- Reproducibility information ---------------------------------------------

cat("\nSession information:\n")
print(sessionInfo())
