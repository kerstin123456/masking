# Study 2: primary and descriptive analyses
# Run R/01_data_preparation.R first.

library(dplyr)

required <- c(
  "catq_compensation", "catq_masking", "catq_assimilation",
  "n_support_types", "any_support", "phq9", "gad7", "whodas", "swls"
)
stopifnot(all(required %in% names(dat)))

# ---- CAT-Q descriptives --------------------------------------------------
dat %>%
  summarise(
    compensation_n = sum(!is.na(catq_compensation)),
    compensation_M = mean(catq_compensation, na.rm = TRUE),
    compensation_SD = sd(catq_compensation, na.rm = TRUE),
    masking_n = sum(!is.na(catq_masking)),
    masking_M = mean(catq_masking, na.rm = TRUE),
    masking_SD = sd(catq_masking, na.rm = TRUE),
    assimilation_n = sum(!is.na(catq_assimilation)),
    assimilation_M = mean(catq_assimilation, na.rm = TRUE),
    assimilation_SD = sd(catq_assimilation, na.rm = TRUE)
  ) %>% print()

# ---- Masking by any formal support --------------------------------------
catq_support <- dat %>%
  filter(!is.na(catq_masking), !is.na(any_support))

catq_support %>%
  group_by(any_support) %>%
  summarise(
    n = n(), M = mean(catq_masking), SD = sd(catq_masking),
    Median = median(catq_masking), IQR = IQR(catq_masking),
    .groups = "drop"
  ) %>% print()

print(wilcox.test(catq_masking ~ any_support, data = catq_support, exact = FALSE))

# ---- CAT-Q and number of formal support types ----------------------------
for (v in c("catq_compensation", "catq_masking", "catq_assimilation")) {
  ok <- complete.cases(dat[[v]], dat$n_support_types)
  cat("\n", v, " x n_support_types\n", sep = "")
  print(cor.test(dat[[v]][ok], dat$n_support_types[ok],
                 method = "spearman", exact = FALSE))
}

# ---- WHODAS by formal support -------------------------------------------
whodas_support <- dat %>%
  filter(!is.na(any_support), !is.na(whodas))

whodas_support %>%
  group_by(any_support) %>%
  summarise(
    n = n(), M = mean(whodas), SD = sd(whodas),
    Median = median(whodas), IQR = IQR(whodas),
    .groups = "drop"
  ) %>% print()

print(wilcox.test(whodas ~ any_support, data = whodas_support, exact = FALSE))

# ---- CAT-Q x clinical variables -----------------------------------------
catq_vars <- c("catq_compensation", "catq_masking", "catq_assimilation")
clinical_vars <- c("phq9", "gad7", "whodas", "swls")

cor_results <- data.frame()
for (x in catq_vars) {
  for (y in clinical_vars) {
    ok <- complete.cases(dat[[x]], dat[[y]])
    test <- cor.test(dat[[x]][ok], dat[[y]][ok],
                     method = "spearman", exact = FALSE)
    cor_results <- rbind(
      cor_results,
      data.frame(
        CATQ = x, Outcome = y, n = sum(ok),
        rho = unname(test$estimate), p = test$p.value
      )
    )
  }
}
print(cor_results, row.names = FALSE)

# ---- Diagnosis comparisons ----------------------------------------------
if (all(c("dx_adhd", "dx_depression", "dx_anxiety") %in% names(dat))) {
  dx_vars <- c("dx_adhd", "dx_depression", "dx_anxiety")
  dx_results <- data.frame()

  for (x in catq_vars) {
    for (d in dx_vars) {
      ok <- complete.cases(dat[[x]], dat[[d]])
      score <- dat[[x]][ok]
      diagnosis <- dat[[d]][ok]
      test <- wilcox.test(score ~ diagnosis, exact = FALSE)

      dx_results <- rbind(
        dx_results,
        data.frame(
          CATQ = x, Diagnosis = d,
          n_no = sum(diagnosis == 0), n_yes = sum(diagnosis == 1),
          Median_no = median(score[diagnosis == 0]),
          Median_yes = median(score[diagnosis == 1]),
          W = unname(test$statistic), p = test$p.value
        )
      )
    }
  }
  print(dx_results, row.names = FALSE)
}

sessionInfo()
